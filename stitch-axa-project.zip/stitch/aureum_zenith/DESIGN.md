# Design System Strategy: The Sovereign Ledger

## 1. Overview & Creative North Star
**Creative North Star: "The Digital Vault"**
This design system moves away from the "SaaS-standard" look of flat cards and grey borders. Instead, it treats the UI as a bespoke, high-end physical asset—like a custom-built vault or a luxury timepiece. We achieve this through **Atmospheric Depth**, **Intentional Asymmetry**, and **Editorial Typography**. 

The goal is to evoke a sense of absolute security and prestige. We replace "utility" with "authority." By leveraging the Slate/Zinc palette as our obsidian-like base and the metallic Gold (`primary`) as our precision instrument, we create an experience that feels curated rather than generated.

---

## 2. Colors & Surface Philosophy
The palette is rooted in the `surface` (`#131315`), a deep, ink-like neutral. 

### The "No-Line" Rule
Traditional 1px borders are strictly prohibited for sectioning. They create visual noise and feel "cheap." Instead, boundaries are defined by:
- **Tonal Shifts:** Placing a `surface-container-low` component against a `surface` background.
- **Negative Space:** Using the `8` (2rem) and `12` (3rem) spacing tokens to create structural "moats" between content blocks.

### Surface Hierarchy & Nesting
Treat the UI as a series of nested, physical layers. 
- **Base Level:** `surface` (#131315) - The foundation.
- **Primary Containers:** `surface-container-low` (#1c1b1d) - Main content areas.
- **High-Interest Cards:** `surface-container-high` (#2a2a2c) - Financial summaries or active project cards.
- **Interactive Elements:** `surface-container-highest` (#353437) - Inputs and dropdown menus.

### The "Glass & Gold" Rule
For floating elements (modals, tooltips, or elevated navigation), use **Glassmorphism**. Apply `surface-variant` with a `40%` opacity and a `20px` backdrop-blur. 
- **CTA Signature:** Main Action buttons should not be flat. Use a subtle linear gradient: `primary` (#f1c97d) to `primary-container` (#d4ad65) at a 135-degree angle to simulate the sheen of brushed gold.

---

## 3. Typography: Editorial Authority
We utilize a dual-typeface system to balance professional rigor with luxury aesthetics.

*   **Display & Headlines (Manrope):** Chosen for its geometric precision and modern "tech-luxury" feel. Use `display-lg` for portfolio totals to command attention.
*   **Body & Titles (Inter):** The workhorse. Used for high-density financial data and project descriptions to ensure maximum legibility at `body-md`.

**The Hierarchy of Wealth:**
*   **IDR Currency:** Always rendered in `title-lg` or `headline-md` using the `primary` gold token. Never use decimals.
*   **Project Labels:** Use `label-sm` with `0.05em` letter-spacing in uppercase to create a "blueprint" aesthetic.

---

## 4. Elevation & Depth
In this system, depth is felt, not seen. 

*   **The Layering Principle:** To lift a financial chart from the background, do not use a shadow. Move from `surface` to `surface-container-low`. The 1% shift in value creates a sophisticated "soft lift."
*   **Ambient Shadows:** If a component must "float" (e.g., a luxury project selector), use a shadow with a `24px` blur, `0%` spread, and `on-surface` color at `6%` opacity. This mimics a soft, natural light source.
*   **Ghost Borders:** If a container needs an edge for accessibility (like an input field), use the `outline-variant` token (#4d4635) at `15%` opacity. 

---

## 5. Components & Data Visualization

### Financial Data Viz
*   **Charts:** Use `primary` (Gold) for growth and `secondary` (Zinc) for benchmarks. Avoid bright greens/reds unless they are critical "Error" or "Success" states.
*   **Indicators:** Positive trends should use a subtle glow (`primary` with a 10px blur) rather than just a plus sign.

### Buttons
*   **Primary:** Gradient of `primary` to `primary-container`. `on-primary` (#412d00) text. Border-radius: `md` (0.375rem).
*   **Secondary:** Ghost style. No background, `outline` token at `20%` opacity.
*   **Tertiary:** Text only in `primary-fixed-dim`.

### Input Fields
*   **Style:** Background set to `surface-container-highest`. No visible border until `:focus`. 
*   **Focus State:** A 1px "Ghost Border" using `primary` at `40%` opacity and a subtle inner-glow.

### Project Cards
*   **Design:** Absolutely no dividers. Use `spacing-6` (1.5rem) to separate the project name from the budget. Use a `surface-container-low` background with a `0.25rem` (DEFAULT) corner radius.

---

## 6. Do’s and Don’ts

### Do:
*   **Use IDR Formatting:** `Rp 1.500.000.000` (No decimals, use period as thousand separator).
*   **Embrace Asymmetry:** Align financial labels to the right and project titles to the left to create a dynamic, editorial feel.
*   **Layering over Lines:** Always try to solve a visual separation problem with a background color shift before reaching for a line or shadow.

### Don’t:
*   **No Pure Black:** Never use `#000000`. It kills the depth of the Slate/Zinc palette. Use `surface`.
*   **No Vibrant Yellows:** The gold must remain metallic and desaturated (`#f1c97d`). If it looks like a "Warning" yellow, it is incorrect.
*   **No Standard Dividers:** Never use `<hr>` or `border-b`. Use vertical padding and tonal shifts to imply the end of a section.
*   **No Default Shadows:** Avoid the standard `shadow-md` or `shadow-lg` from CSS frameworks. They are too dark and muddy for a luxury interface.

---

## 7. Interaction Design (The "Weighted" Feel)
Interactions should feel intentional and heavy.
*   **Hover States:** When hovering over a project card, transition the background from `surface-container-low` to `surface-container-high` over `300ms` with a `cubic-bezier(0.4, 0, 0.2, 1)`.
*   **Micro-animations:** Financial numbers should "count up" subtly upon page load to emphasize growth and activity.